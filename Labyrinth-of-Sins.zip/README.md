Labyrinth of Sine - Computer Graphics Final Project
Developers: Anthony Calabrese & Nate Cefarelli

HOW TO PLAY:

Move Forward - w
Move Left - a
Move Backward - s
Move Right - d
Sprint - shift

Interact - e

Look up - Up arrow key
Look down - Down arrow key
Look left - Left arrow key
Look right - Right arrow key

Look Around - With the mouse

Brightness Settings - 
1-9 
9 is the brightest
0 is default settings

Quit - escape

1) You Were Here...
2) Your Soul Devoid...
3) Tainted By Your Actions, Your sins...
4) There Is No Salvation As I Starve Your Lungs From Within
5) For Eternity, You Shall Morph Into Your Pain...
6) Where Your Eyes Are Ripped Through Your Spine!
7) As You Are Crushed Multidimensionally 
8) As Your Sanity Crumbles...
9) Here You Shall Stay, Under The Nocturnal Sun...
10) For My Almighty Eye To Gaze Upon Your Torment...

